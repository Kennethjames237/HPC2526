import matplotlib
matplotlib.use('Agg') # backend per png
import matplotlib.pyplot as plt
import pandas as pd


df = pd.read_csv("cuda_heat_scaling.csv" ,comment="#",  names=["par", "r", "c", "bx", "by", "gx", "gy",  "iter", "t"])

#print (df)

df2 = df[df["r"] == 2048]
df4 = df[df["r"] == 4096]
df8 = df[df["r"] == 8192]

print (df8)

#plt.subplot(2,1,1)

plt.title('CUDA "HEAT scaling- constant mem & sync-blockes" - Nna Minkousse Kenneth James 21/05/26')

plt.grid()
plt.xlabel('Block_size')
plt.ylabel('time')
plt.yscale('log')
plt.plot(df2.bx,df2.t,'-o', label='2048')
plt.plot(df4.bx,df4.t,'-o', label='4096')
plt.plot(df8.bx,df8.t,'-o', label='8192')
plt.legend(shadow=True,loc="best")


plt.savefig('cuda_heat_scaling_optimize.png')
