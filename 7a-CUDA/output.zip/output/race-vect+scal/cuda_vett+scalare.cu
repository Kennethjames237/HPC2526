#define DESCRIPTION "Using the unified memory to add a scalar number to an array of float using the gpu with 2 blocks 32 thread each \n"

#define ArraySize 64

#include<stdio.h>

__managed__ float A[ArraySize];

__global__ void add_gpu(float *A, float b){
	int global_id = (blockIdx.x * blockDim.x) + threadIdx.x;
	A[global_id] = A[global_id]+b;
}

int main(){
	printf(DESCRIPTION);	


	float b = 5;
	//initialize the array
	for(int i=0; i<ArraySize; i++){
		A[i] = i;
	}
	
	add_gpu<<<2,32>>>(A,b);
	cudaDeviceSynchronize();

	//print the array
	for(int i=0; i<ArraySize; i++){
		printf("%f \n ",A[i]);
	}

}
