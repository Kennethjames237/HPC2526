#define DESCRIPTION \
"This is a small program that demonstrates two situations:\n" \
"1. A race condition.\n" \
"2. A possible solution to avoid a race condition.\n"

#include<stdio.h>

__managed__ int uni_var;

__global__ void race(void){
	__shared__ int var_s;
	
	//initzialise the shared vriable
	if(threadIdx.x == 0){ var_s = 0;}
	__syncthreads();
	
	//race condition
	var_s += threadIdx.x;
	__syncthreads();
	
	//copy the result in a unified memory visible to the CPU and the GPU
	if(threadIdx.x == 0) {uni_var = var_s;}
}

__global__ void noRace(void){
	
	__shared__ int var_s;
	
	//init var_s
	if(threadIdx.x == 0){var_s = 0;}
	__syncthreads();
	
	atomicAdd(&var_s, threadIdx.x);
	__syncthreads();

	//copy the shared variables in the unified memory
	if(threadIdx.x == 0) {uni_var = var_s;}

}

int main(){
	printf(DESCRIPTION);
	printf("\n");
	printf("\n");
	race<<<1,5>>>();
	cudaDeviceSynchronize();
	printf("the result with race condition is: %d \n", uni_var);
	

	noRace<<<1,5>>>();
	cudaDeviceSynchronize();
	printf("The result with no race condition is: %d", uni_var);	

}
