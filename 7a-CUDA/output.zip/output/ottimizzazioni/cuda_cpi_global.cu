#include <stdio.h>
#include <math.h>
#include <unistd.h>    //optarg
#include <time.h>

#define BILLION  1000000000L;

void options(int argc, char * argv[]) ;

int n=500000000;    // intervalli
int nblocks=128;    // numero blocchi
int  threadsPerBlock = 1024;
const double  PI = 3.14159265358979323846264338327950288 ;
__managed__ float unified[128*1024];
__global__ void add(void) {
	// each thread computes its global_ID and calculate its own part of PI and
	// store the result in its corresponding possition in the global memory array[res1]
       long int tid = threadIdx.x + blockIdx.x * blockDim.x;

        double h = 1.0 / (double)(gridDim.x * blockDim.x);
        double x = h * ((double)tid - 0.5);
        double pi1 = (1.0 / (1.0 + x*x)); // f1
	unified[tid] = pi1 * 4 * h;

         __syncthreads();
    //Reduction is done on the first thread of each block but on the global memory
    // because this array will ne forwarded to the CPU for further reduction
   int i = blockDim.x/2;
   __syncthreads();
   while (i != 0) {
   	 if (threadIdx.x < i)
	 unified[tid] += unified[tid + i];
	 __syncthreads();
	 i /= 2;
   }
}

/************************************************/

int main(int argc, char **argv ) { 

    options(argc, argv);  /* optarg management */

    n=nblocks*threadsPerBlock; 


    struct timespec t1,t2,t3,t4;
    double wtime, ktime;  // WallTime, KernelTime, MemcopyTime
 
   clock_gettime( CLOCK_REALTIME , &t1) ;

    add<<<nblocks,threadsPerBlock>>>();
    cudaDeviceSynchronize();
    clock_gettime( CLOCK_REALTIME , &t2) ;

    clock_gettime( CLOCK_REALTIME , &t3) ;
	
	// After reciving the array from the global memory of the 
	//GPU it performs the reduction iterating on only the first position on the block
    float total1=0;
    for (long int i=0;i<n;i+=threadsPerBlock)  total1+=unified[i];

    clock_gettime( CLOCK_REALTIME , &t4 ) ;

    wtime = (double) ( t4.tv_sec  - t1.tv_sec )
          + (double) ( t4.tv_nsec - t1.tv_nsec )
            / BILLION;




    ktime = (double)  ( t2.tv_sec  - t1.tv_sec )
           + (double) ( t2.tv_nsec - t1.tv_nsec )
            / BILLION;


    fprintf(stderr,"#intervals blocks pi error wtime(s) ktime(s) \n");
    fprintf(stderr,"CUDA, %d, %d, %d, %.10f, %.10e, %.4f, %.4f \n", 
          n, nblocks, threadsPerBlock, total1,  fabs(total1 - PI), wtime, ktime);
    return 0; 
}


/************************************************/

void options(int argc, char * argv[])
{
  int i;
   while ( (i = getopt(argc, argv, "t:b:h")) != -1) {
        switch (i)
        {
        case 'b':  nblocks         = strtol(optarg, NULL, 10);  break;
        case 't':  threadsPerBlock = strtol(optarg, NULL, 10);  break;
        case 'h':  printf ("\n%s [-b blocks] [-h]",argv[0]); exit(1);
        default:   printf ("\n%s [-b blocks] [-h]",argv[0]);  exit(1);
        }
    }
}

