#!/bin/sh

# https://www.open-mpi.org/doc/v4.1/

HOSTNAME=$(hostname)

mpicc mpi_bandwidth.c -o mpi_bandwidth
mpicc mpi_latency.c  -o mpi_latency

mpirun -npernode 2 -np 2 -host wn1:4       mpi_bandwidth 2> band1-$HOSTNAME.csv
mpirun -npernode 1 -np 2 -host wn1:4,wn2:4 mpi_bandwidth 2> band2-$HOSTNAME.csv

mpirun -npernode 2 -np 2 -host wn1:4       mpi_latency   2> lat1-$HOSTNAME.csv
mpirun -npernode 1 -np 2 -host wn1:4,wn2:4 mpi_latency   2> lat2-$HOSTNAME.csv

